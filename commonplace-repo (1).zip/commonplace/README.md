# Commonplace

**One shared, permissioned memory for every AI agent.** Think Git for agent memory.

AI agents each live in their own bubble: your coding assistant, email assistant and research assistant never share what they learn. Commonplace is a memory layer they can all read and write, with provenance, conflict detection and privacy built in.

## Features

- **Shared memory:** tell one agent a fact, and every other agent can use it.
- **Provenance:** each entry records its author and timestamp.
- **Conflict detection:** disagreements are flagged, never silently overwritten.
- **Corroboration:** independent confirmations raise confidence.
- **Privacy:** private entries are readable only by their author.
- **Human in the loop:** a person resolves disputes.

## Quick start

Explainer: open `web/explainer.html` and press Play.

Web demo (no install): open `web/index.html` in a browser and press **Run the 30-second demo**.

Python core:

```bash
python examples/demo.py
pip install pytest && pytest
```

```python
from commonplace import Memory

m = Memory()
m.write("coder", "staging database", "Postgres 15")
m.read("mailer", "What is the staging database?")      # -> [Fact(value='Postgres 15', agent='coder')]
r = m.write("researcher", "staging database", "MySQL 8")  # r["kind"] == "conflict"
m.resolve(r["fact"].id)
```

## Repo layout

```
web/index.html        interactive demo (single file)
web/explainer.html     45-second animated explainer (screen-record it for a video)
commonplace/memory.py core memory logic
tests/                pytest suite
examples/demo.py      scripted walkthrough
```

## Roadmap

- [ ] Expose the memory as an MCP server so any MCP-compatible agent can connect
- [ ] Persistent storage (SQLite, then Postgres)
- [ ] Semantic retrieval with embeddings, plus a graph of related facts
- [ ] LLM-based fact extraction instead of "X is Y" rules
- [ ] Per-agent access policies and audit log

## License

MIT
