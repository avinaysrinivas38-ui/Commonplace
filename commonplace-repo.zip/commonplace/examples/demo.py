import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from commonplace import Memory

m = Memory()
m.write("coder", "staging database", "Postgres 15")
print("Mailer asks:", [(f.value, f.agent) for f in m.read("mailer", "staging database")])
r = m.write("researcher", "staging database", "MySQL 8")
print("Researcher writes:", r["kind"])
print("Coder asks:", [(f.value, f.agent, f.state) for f in m.read("coder", "staging database")])
m.resolve(r["fact"].id)
print("After resolve:", [(f.value, f.state) for f in m.read("coder", "staging database")])
