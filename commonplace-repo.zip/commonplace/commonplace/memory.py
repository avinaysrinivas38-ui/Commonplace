"""Shared, permissioned memory for multiple agents, with provenance and conflict detection."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import List, Optional

STOP = re.compile(r"\b(the|our|a|an|we|current|currently|my|what|whats|who|where|which|is|are|uses|use)\b")


def norm(s: str) -> str:
    s = re.sub(r"[?.!]+$", "", s.lower().replace("'s", "s"))
    return re.sub(r"\s+", " ", STOP.sub(" ", s)).strip()


@dataclass
class Fact:
    id: int
    key: str
    value: str
    agent: str
    t: float = field(default_factory=time.time)
    private: bool = False
    state: str = "active"  # active | disputed | superseded
    confirmed_by: List[str] = field(default_factory=list)


class Memory:
    def __init__(self) -> None:
        self.facts: List[Fact] = []
        self._seq = 0

    def write(self, agent: str, key: str, value: str, private: bool = False) -> dict:
        key = norm(key)
        live = [f for f in self.facts if f.key == key and f.state != "superseded"]
        for f in live:
            if f.value.lower() == value.lower():
                if agent != f.agent and agent not in f.confirmed_by:
                    f.confirmed_by.append(agent)
                return {"kind": "agree", "fact": f}
        mine = next((f for f in live if f.agent == agent), None)
        others = [f for f in live if f.agent != agent and not f.private and not private]
        self._seq += 1
        new = Fact(self._seq, key, value, agent, private=private)
        if mine:
            mine.state = "superseded"
        self.facts.append(new)
        if others:
            new.state = "disputed"
            for o in others:
                o.state = "disputed"
            return {"kind": "conflict", "fact": new, "others": others}
        return {"kind": "new", "fact": new, "replaced": bool(mine)}

    def read(self, agent: str, key: str) -> List[Fact]:
        key = norm(key)
        if not key:
            return []
        return [
            f for f in self.facts
            if f.state != "superseded" and (not f.private or f.agent == agent)
            and (f.key == key or key in f.key or f.key in key)
        ]

    def resolve(self, fact_id: int) -> Optional[Fact]:
        chosen = next((f for f in self.facts if f.id == fact_id), None)
        if not chosen:
            return None
        for f in self.facts:
            if f.key == chosen.key and f.state == "disputed":
                f.state = "active" if f.id == chosen.id else "superseded"
        return chosen
