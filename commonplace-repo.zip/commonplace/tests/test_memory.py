from commonplace import Memory


def test_share_between_agents():
    m = Memory()
    m.write("coder", "staging database", "Postgres 15")
    hits = m.read("mailer", "What is the staging database?")
    assert hits[0].value == "Postgres 15" and hits[0].agent == "coder"


def test_conflict_and_resolve():
    m = Memory()
    m.write("coder", "staging database", "Postgres 15")
    r = m.write("researcher", "staging database", "MySQL 8")
    assert r["kind"] == "conflict"
    assert all(f.state == "disputed" for f in m.read("coder", "staging database"))
    m.resolve(r["fact"].id)
    assert [f.value for f in m.read("coder", "staging database")] == ["MySQL 8"]


def test_private_is_hidden():
    m = Memory()
    m.write("coder", "api key owner", "Priya", private=True)
    assert m.read("mailer", "api key owner") == []
    assert len(m.read("coder", "api key owner")) == 1


def test_corroboration():
    m = Memory()
    m.write("coder", "region", "ap-south-1")
    r = m.write("mailer", "region", "ap-south-1")
    assert r["kind"] == "agree" and r["fact"].confirmed_by == ["mailer"]
